# Maintained Langfuse OTel 3 port

Private, source-maintained port of `@langfuse/otel` 6.0.1 for OpenTelemetry 3.
This is not an upstream Langfuse release. `provenance.json` records upstream
commit, npm integrity, original source hashes and the bounded changes. MIT
license is retained unchanged.

The port uses `@opentelemetry/sdk-trace` and its options-object processor
constructors. Filtering, masking, ingestion version 4 and SDK headers retain
upstream contracts. The maintained media path additionally accepts
`mediaUploadSignal`: cancellation covers URL allocation, byte upload, status
PATCH, response bodies and retry waits. A narrow transport for the two media API
endpoints avoids the core client's leaked timeout on rejected fetches; it uses
real core request/response types and preserves media IDs, upload headers and
HTTP retry policy. Ready spans flush independently of stalled media uploads;
normal shutdown still waits for both. Callers without an owning cancellation
signal retain ordinary upstream request/upload timing rather than a new global
deadline. Consumers use
`TracerProvider`, `AsyncLocalStorageContextManager`, and direct resources imports.
Requires Node >=22.15 and Langfuse Cloud or self-hosted Langfuse >=4.59.0.

```bash
npm ci --ignore-scripts --strict-peer-deps
npm run typecheck
npm test
```

`npm test` builds twice and compares bytes, packs the real distribution, installs
it with strict peers into a fresh temporary project (no dependency symlinks),
checks ESM/CJS and genuine declarations, exercises real spans and loopback HTTP
exports, and audits its production tree. No live credentials or service calls.
This package proof does not establish the consumer's fresh/reused deployment.

Build uses pinned esbuild and the TypeScript CLI. Generated `dist/` is not edited
by hand; source, build inputs and lockfile are canonical. Retirement condition:
an upstream Langfuse release supports OTel 3 and passes the same contracts.
